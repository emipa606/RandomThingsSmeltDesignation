﻿using RimWorld;
using System;
using UnityEngine;
using Verse;

namespace SmeltDesignation
{
	[DefOf]
	public static class SmeltDefOf
	{
		public static DesignationDef SmeltDesignation;
	}
}